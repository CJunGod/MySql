CREATE TABLE `user`(
	username VARCHAR(20) PRIMARY KEY NOT NULL COMMENT '用户名',
	`password` VARCHAR(20) NOT NULL COMMENT '密码',
	`email` VARCHAR(20) NOT NULL COMMENT '邮箱地址'
)COMMENT='用户表'; 

CREATE TABLE email(
	msgid INT PRIMARY KEY AUTO_INCREMENT NOT NULL COMMENT '短信id',
	username VARCHAR(20) NOT NULL COMMENT '短信息发送方',
	title VARCHAR(40) NOT NULL COMMENT '标题',
	msgcontent VARCHAR(400) NOT NULL COMMENT '消息内容',
	state INT NOT NULL COMMENT '消息状态',
	sendto VARCHAR(20) NOT NULL COMMENT '短信息接收方',
	msg_create_date DATETIME NOT NULL COMMENT '消息发送时间'
)COMMENT='邮箱表';

INSERT INTO USER (username,PASSWORD,email) VALUES ('admin','admin','1038804380@qq.com')

SELECT * FROM USER WHERE username='admin' AND PASSWORD='admin'

INSERT INTO email (username,title,msgcontent,state,sendto,msg_create_date) VALUES ('123456','本标题只测试不参与任何操作','本标题只测试不参与任何操作',0,'admin','2018-11-6 21:28')